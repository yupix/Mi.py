Unless otherwise stated this repository is
Copyright © 2021 yupix and contributers

Mi.py includes several third-party Open-Source softwares.

And is distributed under The MIT LICENSE, you should have received a copy of the license file as LICENSE.


discord.py by Rapptz
License: MIT
https://github.com/Rapptz/discord.py/blob/master/LICENSE
